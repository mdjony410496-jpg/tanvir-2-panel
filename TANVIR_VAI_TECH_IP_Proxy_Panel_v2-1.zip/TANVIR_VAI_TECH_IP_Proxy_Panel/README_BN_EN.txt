# TANVIR VAI TECH IP/Proxy Sharing Panel

A small Supabase-backed starter project with:
- Individual email/password accounts
- New signups remain pending until an admin approves them
- Admin-only country management
- Admin-only IP/proxy entry upload and deletion
- Approved users can view and copy entries
- Row Level Security (RLS) policies on all tables

## Important security notes
- This project does not contain any Supabase credentials.
- Use only the Supabase Project URL and public anon/publishable key in the browser.
- NEVER put the `service_role` key or any secret key in `index.html`.
- Proxy strings may contain usernames/passwords. Only store/share proxies you are authorized to share, and only with trusted approved members.
- This starter uses one approval flag for all lists. If each member should see only selected countries, that needs an additional per-user country permission table and policies.
- Do not assume a country label means an IP is physically located there; it is only a label you assign.

## Setup (beginner friendly)

### 1. Create a Supabase project
1. Open https://supabase.com and sign in.
2. Create a new project and save its database password somewhere safe.
3. Open Project Settings / API (the exact menu label may vary).
4. Copy the Project URL and the public `anon` / `publishable` key. Do not copy a `service_role` or secret key.

### 2. Create the database tables and access rules
1. In the Supabase project, open **SQL Editor**.
2. Open the included `supabase/schema.sql` file in a text editor.
3. Copy all SQL into the SQL Editor and run it.
4. Check that `profiles`, `countries`, and `proxy_entries` tables were created.

### 3. Publish the website
You can use Netlify, Cloudflare Pages, or another static hosting service:
1. Upload `index.html` as the site file (or deploy the project folder from Git).
2. Open the public website URL.
3. Paste the Supabase Project URL and public anon/publishable key into the setup panel and click **Save & Connect**.
4. The URL and public key are saved only in that browser's local storage. Other members must enter the same project URL/key once on their own device.

### 4. Make your account the first admin
1. Open the deployed website and create your own account using **Request account**.
2. If Supabase email confirmation is enabled, confirm your email first.
3. In Supabase SQL Editor, run the following after replacing the email with your exact login email:

```sql
update public.profiles
set role = 'admin', approved = true
where lower(email) = lower('YOUR_LOGIN_EMAIL');
```

4. Sign out and sign back in on the website.
5. You should now see Admin controls. Do not give admin access to other accounts unless trusted.

### 5. Approve members
1. Tell members to open the site and use **Request account** with their own email/password.
2. Their account must exist in Supabase Auth and the `profiles` table.
3. Log in as Admin. In **User approvals**, click **Approve**.
4. The member must log out and log back in if their view does not update immediately.
5. To remove access, click **Revoke**. This sets `approved=false`.

### 6. Add countries and entries
1. Under Country Panel, add or enable a country.
2. In the Admin-only form, choose `IP address` or `Proxy`.
3. Paste one entry per line and click **Save entries**.
4. Approved members can select the country, search, and copy entries.

## Troubleshooting
- **Profile not found / schema error:** run `schema.sql` fully and check the trigger exists.
- **Email confirmation:** check Supabase Auth settings and your email inbox.
- **Can't sign in:** verify the URL/key and that the account was created successfully.
- **Can't see Admin controls:** run the first-admin SQL with the exact email, then sign out and sign back in.
- **Anyone can see lists without login:** stop using the site until you confirm RLS is enabled and the included SQL policies are installed.
- **Database password / secret leaked:** rotate it in Supabase settings.

## Current limitations
- This is a starter implementation, not a professionally audited service.
- The website is a static front end; authentication, storage and access checks are handled by Supabase RLS.
- Admin approval is global, not country-specific.
- The `profiles` table only allows admins to update profiles under RLS. First admin is bootstrapped manually through SQL.


## Short Panel (compact user view)
- New file: `short-panel.html`.
- Deploy it beside `index.html` on the SAME site/domain.
- It uses the same Supabase URL, public key, Auth, `profiles`, `countries`, and `proxy_entries` tables.
- Admin controls country availability and entries from `index.html`; `short-panel.html` reads the same database, so changes appear there after refresh/reload.
- The short panel displays up to four enabled countries. To show your chosen 3-4 countries, disable the others in Main Admin Panel. The current starter has global country visibility, not per-user country permissions.
