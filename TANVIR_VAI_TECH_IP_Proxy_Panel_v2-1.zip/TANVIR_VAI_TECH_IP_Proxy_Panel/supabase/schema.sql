-- TANVIR VAI TECH IP/Proxy Panel schema
-- Run this entire file in Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  role text not null default 'member' check (role in ('admin','member')),
  approved boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.countries (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  enabled boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.proxy_entries (
  id uuid primary key default gen_random_uuid(),
  country_id uuid not null references public.countries(id) on delete cascade,
  entry_type text not null check (entry_type in ('ip','proxy')),
  entry_text text not null,
  created_at timestamptz not null default now()
);

create index if not exists proxy_entries_country_created_idx
  on public.proxy_entries(country_id, created_at desc);

-- Helper function avoids recursive profiles RLS checks.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = (select auth.uid()) and p.role = 'admin'
  );
$$;

create or replace function public.is_approved()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = (select auth.uid()) and (p.role = 'admin' or p.approved = true)
  );
$$;

-- Create a pending member profile automatically when a new auth account signs up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, email, role, approved)
  values (new.id, new.email, 'member', false)
  on conflict (id) do update set email = excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.countries enable row level security;
alter table public.proxy_entries enable row level security;

drop policy if exists "Profiles readable by self or admin" on public.profiles;
create policy "Profiles readable by self or admin"
on public.profiles for select to authenticated
using (id = (select auth.uid()) or (select public.is_admin()));

drop policy if exists "Admins update profiles" on public.profiles;
create policy "Admins update profiles"
on public.profiles for update to authenticated
using ((select public.is_admin()))
with check ((select public.is_admin()));

drop policy if exists "Approved members read countries" on public.countries;
create policy "Approved members read countries"
on public.countries for select to authenticated
using ((select public.is_approved()) and (enabled = true or (select public.is_admin())));

drop policy if exists "Admins insert countries" on public.countries;
create policy "Admins insert countries"
on public.countries for insert to authenticated
with check ((select public.is_admin()));

drop policy if exists "Admins update countries" on public.countries;
create policy "Admins update countries"
on public.countries for update to authenticated
using ((select public.is_admin()))
with check ((select public.is_admin()));

drop policy if exists "Admins delete countries" on public.countries;
create policy "Admins delete countries"
on public.countries for delete to authenticated
using ((select public.is_admin()));

drop policy if exists "Approved members read entries" on public.proxy_entries;
create policy "Approved members read entries"
on public.proxy_entries for select to authenticated
using ((select public.is_approved()) and exists (
  select 1 from public.countries c
  where c.id = country_id and (c.enabled = true or (select public.is_admin()))
));

drop policy if exists "Admins insert entries" on public.proxy_entries;
create policy "Admins insert entries"
on public.proxy_entries for insert to authenticated
with check ((select public.is_admin()));

drop policy if exists "Admins delete entries" on public.proxy_entries;
create policy "Admins delete entries"
on public.proxy_entries for delete to authenticated
using ((select public.is_admin()));

-- Seed country list. You can edit these in the Admin Panel later.
insert into public.countries (name, enabled) values
 ('USA',true),('UK',true),('Canada',true),('Finland',true),
 ('Denmark',true),('Norway',true),('Australia',true),('Germany',true)
on conflict (name) do nothing;

-- IMPORTANT: Create your account via the website first, confirm email if configured,
-- then replace YOUR_LOGIN_EMAIL below with your own exact login email and run this
-- statement separately. It promotes ONLY that account to the first admin.
-- update public.profiles set role = 'admin', approved = true
-- where lower(email) = lower('YOUR_LOGIN_EMAIL');
